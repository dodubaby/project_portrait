package com.rat.entity.network.request;

import com.rat.entity.network.request.base.ActionInfo;

/**
 * author : L.jinzhu
 * date : 2015/8/12
 * introduce : 请求实体
 */
public class NewVersionActionInfo extends ActionInfo {
    public NewVersionActionInfo(int actionId) {
        super(actionId);
    }
}