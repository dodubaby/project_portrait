package com.rat.entity.network.response.base;

import java.io.Serializable;

/**
 * @author shisheng.zhao
 * @Description:响应回执公共基类
 * @date 2015-08-31 上午12:01:22
 */
public abstract class AbstractResponseInfo implements Serializable {

    private static final long serialVersionUID = 1L;
}
