#!/usr/bin/python3
# coding=utf-8

addressKeyList = {'1': '村委会', '2': '学校', '3': '商场', '4': '超市', '5': '电影院', '6': '医院', '7': '银行'}

